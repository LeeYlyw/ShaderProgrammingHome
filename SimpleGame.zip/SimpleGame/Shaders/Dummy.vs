#version 330

in vec3 a_Position;

uniform vec4 u_Trans;
uniform float u_Time;

out float v_Grey;
out vec2 v_Tex;

float c_PI = 3.141592;

void Frag()
{
    float tx, ty;

    tx = a_Position.x + 0.5;
    ty = 1.0 - (a_Position.y + 0.5);
    v_Tex = vec2(tx, ty);

    float value = a_Position.x + 0.5;
    float newX = a_Position.x;

    float newY = a_Position.y +
        value * 0.25 * sin((newX + 0.5) * 2.0 * c_PI - u_Time);

    vec4 finalPos = vec4(newX, newY, 0.0, 1.0);

    vec4 newPosition = finalPos;

    float grey =
        (sin((newX + 0.5) * 2.0 * c_PI - u_Time) + 1.0) / 2.0;

    v_Grey = grey;

    gl_Position = newPosition;
}

void main()
{
    Frag();
}