#version 330

layout(location = 0) in vec3 a_Position;
layout(location = 1) in vec2 a_Tex;

out vec2 v_Tex;

void main()
{
    gl_Position = vec4(a_Position, 1.0);
    v_Tex = a_Tex;
}