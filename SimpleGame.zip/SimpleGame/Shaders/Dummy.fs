#version 330

uniform sampler2D u_AhnTex;

in float v_Grey;
in vec2 v_Tex;

out vec4 FragColor;

void main()
{
    FragColor = vec4(v_Grey, v_Grey, v_Grey, 1.0);

        FragColor = vec4(v_Tex, 0, 1);

}